export class CheckoutShipping {     
  constructor() {
    this.message = 'Hello world';
  }
}