export function configure(config) {
    //config.globalResources([]);
  }
  