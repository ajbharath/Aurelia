export class Product{
    constructor(name, id, price, imageUrl, description){
        this.name = name;
        this.id = id;
        this.price = price;
        this.imageUrl = imageUrl;
        this.description = description;
    }
}