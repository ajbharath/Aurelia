export class ProductDetails {     
  constructor() {
    this.message = 'Hello world';
  }
}